import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_FILE = os.path.join(BASE_DIR, "school.db")

ROLES = ["Administrator", "Teacher", "Principal"]


def get_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialise_database():
    conn = get_connection()
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('Administrator','Teacher','Principal')),
        teacher_id INTEGER,
        FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS teachers (
        teacher_id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        specialty TEXT
    );

    CREATE TABLE IF NOT EXISTS classes (
        class_id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_name TEXT NOT NULL,
        grade_level TEXT NOT NULL,
        class_teacher_id INTEGER,
        current_year INTEGER,
        FOREIGN KEY (class_teacher_id) REFERENCES teachers(teacher_id)
    );

    CREATE TABLE IF NOT EXISTS students (
        student_id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        date_of_birth TEXT,
        gender TEXT,
        class_id INTEGER,
        parent_contact TEXT,
        address TEXT,
        FOREIGN KEY (class_id) REFERENCES classes(class_id)
    );

    CREATE TABLE IF NOT EXISTS subjects (
        subject_id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_name TEXT NOT NULL,
        grade INTEGER,
        teacher_id INTEGER,
        FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS teacher_subject (
        teacher_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        PRIMARY KEY (teacher_id, subject_id),
        FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS enrollment (
        enrollment_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        academic_year TEXT NOT NULL,
        FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS marks (
        mark_id INTEGER PRIMARY KEY AUTOINCREMENT,
        enrollment_id INTEGER NOT NULL,
        term TEXT NOT NULL,
        score REAL NOT NULL CHECK(score >= 0 AND score <= 100),
        test_mark REAL,
        exam_mark REAL,
        FOREIGN KEY (enrollment_id) REFERENCES enrollment(enrollment_id) ON DELETE CASCADE
    );

    -- Which class a student is placed in for a given year (from the MySQL 'enrollment' table).
    CREATE TABLE IF NOT EXISTS class_enrollment (
        class_enrollment_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        class_id INTEGER NOT NULL,
        enrollment_year INTEGER NOT NULL,
        enrollment_status TEXT NOT NULL,
        FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
        FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS attendance (
        attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        attendance_date TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late')),
        FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
    );
    """)

    _ensure_columns(cur)

    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO users (username, password, role) VALUES (?,?,?)",
            [
                ("admin", "admin123", "Administrator"),
                ("teacher1", "teacher123", "Teacher"),
                ("principal", "principal123", "Principal"),
            ],
        )
    conn.commit()
    conn.close()


def _ensure_columns(cur):
    """Upgrade a database created with the older schema by adding the new columns."""
    wanted = {
        "classes": [("current_year", "INTEGER")],
        "subjects": [("grade", "INTEGER"), ("teacher_id", "INTEGER")],
        "users": [("teacher_id", "INTEGER")],
        "marks": [("test_mark", "REAL"), ("exam_mark", "REAL")],
    }
    for table, cols in wanted.items():
        existing = {r[1] for r in cur.execute(f'PRAGMA table_info("{table}")')}
        for name, col_type in cols:
            if name not in existing:
                cur.execute(f'ALTER TABLE "{table}" ADD COLUMN "{name}" {col_type}')


# Subject names repeat across grades (e.g. English in Grades 8-12), so every place a
# subject is shown to a person uses this label: "English (Grade 8)".
SUBJECT_LABEL = "subjects.subject_name || COALESCE(' (Grade ' || subjects.grade || ')', '')"


def _execute(sql, params=(), fetch=False, many=False):
    conn = get_connection()
    try:
        cur = conn.cursor()
        if many:
            cur.executemany(sql, params)
        else:
            cur.execute(sql, params)
        rows = cur.fetchall() if fetch else None
        conn.commit()
        return rows
    finally:
        conn.close()


def verify_login(username, password):
    rows = _execute(
        "SELECT user_id, role FROM users WHERE username=? AND password=?",
        (username, password), True
    )
    return rows[0] if rows else None


def add_user(username, password, role):
    _execute("INSERT INTO users (username,password,role) VALUES (?,?,?)", (username, password, role))


def get_all_users():
    return _execute("SELECT user_id, username, role FROM users ORDER BY user_id", fetch=True)


def delete_user(user_id):
    _execute("DELETE FROM users WHERE user_id=?", (user_id,))


def add_teacher(first, last, phone, email, specialty):
    _execute("INSERT INTO teachers (first_name,last_name,phone,email,specialty) VALUES (?,?,?,?,?)", (first,last,phone,email,specialty))


def get_all_teachers():
    return _execute("SELECT * FROM teachers ORDER BY teacher_id", fetch=True)


def update_teacher(teacher_id, first, last, phone, email, specialty):
    _execute("UPDATE teachers SET first_name=?,last_name=?,phone=?,email=?,specialty=? WHERE teacher_id=?", (first,last,phone,email,specialty,teacher_id))


def delete_teacher(teacher_id):
    """Classes they were homeroom teacher of become '(none)'; subject/user links are cleared by the schema."""
    conn = get_connection()
    try:
        conn.execute("UPDATE classes SET class_teacher_id=NULL WHERE class_teacher_id=?", (teacher_id,))
        conn.execute("DELETE FROM teachers WHERE teacher_id=?", (teacher_id,))
        conn.commit()
    finally:
        conn.close()


def get_teacher_choices():
    return _execute("SELECT teacher_id, first_name || ' ' || last_name FROM teachers ORDER BY last_name", fetch=True)


def add_class(class_name, grade_level, class_teacher_id, current_year=None):
    _execute("INSERT INTO classes (class_name,grade_level,class_teacher_id,current_year) VALUES (?,?,?,?)",
             (class_name,grade_level,class_teacher_id,current_year))


def update_class(class_id, class_name, grade_level, class_teacher_id):
    _execute("UPDATE classes SET class_name=?,grade_level=?,class_teacher_id=? WHERE class_id=?",
             (class_name, grade_level, class_teacher_id, class_id))


def get_all_classes():
    return _execute("""SELECT classes.class_id, classes.class_name, classes.grade_level,
        COALESCE(teachers.first_name || ' ' || teachers.last_name, '(none)')
        FROM classes LEFT JOIN teachers ON classes.class_teacher_id=teachers.teacher_id
        ORDER BY classes.class_id""", fetch=True)


def delete_class(class_id):
    """Students in the class are kept and become unassigned; class enrollment rows are removed."""
    conn = get_connection()
    try:
        conn.execute("UPDATE students SET class_id=NULL WHERE class_id=?", (class_id,))
        conn.execute("DELETE FROM classes WHERE class_id=?", (class_id,))
        conn.commit()
    finally:
        conn.close()


def get_class_choices():
    return _execute("SELECT class_id, class_name FROM classes ORDER BY class_name", fetch=True)


def add_student(first,last,dob,gender,class_id,parent_contact,address):
    _execute("""INSERT INTO students
        (first_name,last_name,date_of_birth,gender,class_id,parent_contact,address)
        VALUES (?,?,?,?,?,?,?)""", (first,last,dob,gender,class_id,parent_contact,address))


def get_all_students():
    return _execute("""SELECT students.student_id, students.first_name, students.last_name,
        students.date_of_birth, students.gender,
        COALESCE(classes.class_name,'(unassigned)'), students.parent_contact, students.address
        FROM students LEFT JOIN classes ON students.class_id=classes.class_id
        ORDER BY students.student_id""", fetch=True)


def update_student(student_id,first,last,dob,gender,class_id,parent_contact,address):
    _execute("""UPDATE students SET first_name=?,last_name=?,date_of_birth=?,gender=?,
        class_id=?,parent_contact=?,address=? WHERE student_id=?""",
        (first,last,dob,gender,class_id,parent_contact,address,student_id))


def delete_student(student_id):
    _execute("DELETE FROM students WHERE student_id=?", (student_id,))


def get_student_choices():
    return _execute("SELECT student_id, first_name || ' ' || last_name FROM students ORDER BY last_name", fetch=True)


def search_students(keyword):
    like=f"%{keyword}%"
    return _execute("""SELECT students.student_id, students.first_name, students.last_name,
        students.date_of_birth, students.gender, COALESCE(classes.class_name,'(unassigned)'),
        students.parent_contact, students.address
        FROM students LEFT JOIN classes ON students.class_id=classes.class_id
        WHERE students.first_name LIKE ? OR students.last_name LIKE ?
        ORDER BY students.student_id""", (like,like), True)


def add_subject(subject_name, grade=None, teacher_id=None):
    _execute("INSERT INTO subjects (subject_name,grade,teacher_id) VALUES (?,?,?)",
             (subject_name, grade, teacher_id))


def get_all_subjects():
    """Rows: (subject_id, subject_name, grade, lead teacher name)."""
    return _execute("""SELECT subjects.subject_id, subjects.subject_name, subjects.grade,
        COALESCE(teachers.first_name || ' ' || teachers.last_name, '(none)')
        FROM subjects LEFT JOIN teachers ON subjects.teacher_id=teachers.teacher_id
        ORDER BY subjects.subject_id""", fetch=True)


def delete_subject(subject_id):
    _execute("DELETE FROM subjects WHERE subject_id=?", (subject_id,))


def get_subject_choices():
    return _execute(f"SELECT subject_id, {SUBJECT_LABEL} FROM subjects ORDER BY subject_name, grade", fetch=True)


def assign_teacher_to_subject(teacher_id,subject_id):
    _execute("INSERT OR IGNORE INTO teacher_subject (teacher_id,subject_id) VALUES (?,?)", (teacher_id,subject_id))


def get_all_teacher_subjects():
    return _execute(f"""SELECT teachers.teacher_id, teachers.first_name || ' ' || teachers.last_name,
        subjects.subject_id, {SUBJECT_LABEL}
        FROM teacher_subject JOIN teachers ON teacher_subject.teacher_id=teachers.teacher_id
        JOIN subjects ON teacher_subject.subject_id=subjects.subject_id
        ORDER BY teachers.teacher_id, subjects.subject_id""", fetch=True)


def remove_teacher_subject(teacher_id,subject_id):
    _execute("DELETE FROM teacher_subject WHERE teacher_id=? AND subject_id=?", (teacher_id,subject_id))


def enroll_student(student_id,subject_id,academic_year):
    _execute("INSERT INTO enrollment (student_id,subject_id,academic_year) VALUES (?,?,?)", (student_id,subject_id,academic_year))


def get_all_enrollments():
    return _execute(f"""SELECT enrollment.enrollment_id,
        students.first_name || ' ' || students.last_name, {SUBJECT_LABEL}, enrollment.academic_year
        FROM enrollment JOIN students ON enrollment.student_id=students.student_id
        JOIN subjects ON enrollment.subject_id=subjects.subject_id ORDER BY enrollment.enrollment_id""", fetch=True)


def delete_enrollment(enrollment_id):
    _execute("DELETE FROM enrollment WHERE enrollment_id=?", (enrollment_id,))


def get_enrollment_choices():
    return _execute(f"""SELECT enrollment.enrollment_id,
        students.first_name || ' ' || students.last_name || ' - ' || {SUBJECT_LABEL} || ' (' || enrollment.academic_year || ')'
        FROM enrollment JOIN students ON enrollment.student_id=students.student_id
        JOIN subjects ON enrollment.subject_id=subjects.subject_id ORDER BY students.last_name""", fetch=True)


def add_mark(enrollment_id,term,score,test_mark=None,exam_mark=None):
    _execute("INSERT INTO marks (enrollment_id,term,score,test_mark,exam_mark) VALUES (?,?,?,?,?)",
             (enrollment_id,term,score,test_mark,exam_mark))


def get_all_marks():
    return _execute(f"""SELECT marks.mark_id,
        students.first_name || ' ' || students.last_name, {SUBJECT_LABEL}, marks.term, marks.score,
        marks.test_mark, marks.exam_mark
        FROM marks JOIN enrollment ON marks.enrollment_id=enrollment.enrollment_id
        JOIN students ON enrollment.student_id=students.student_id
        JOIN subjects ON enrollment.subject_id=subjects.subject_id ORDER BY marks.mark_id""", fetch=True)


def get_all_class_enrollments():
    """Class placement per year (imported from the MySQL 'enrollment' table)."""
    return _execute("""SELECT class_enrollment.class_enrollment_id,
        students.first_name || ' ' || students.last_name, classes.class_name,
        class_enrollment.enrollment_year, class_enrollment.enrollment_status
        FROM class_enrollment JOIN students ON class_enrollment.student_id=students.student_id
        JOIN classes ON class_enrollment.class_id=classes.class_id
        ORDER BY class_enrollment.class_enrollment_id""", fetch=True)


def delete_mark(mark_id):
    _execute("DELETE FROM marks WHERE mark_id=?", (mark_id,))


def mark_attendance(student_id,attendance_date,status):
    _execute("INSERT INTO attendance (student_id,attendance_date,status) VALUES (?,?,?)", (student_id,attendance_date,status))


def get_all_attendance():
    return _execute("""SELECT attendance.attendance_id,
        students.first_name || ' ' || students.last_name, attendance.attendance_date, attendance.status
        FROM attendance JOIN students ON attendance.student_id=students.student_id
        ORDER BY attendance.attendance_id""", fetch=True)


def delete_attendance(attendance_id):
    _execute("DELETE FROM attendance WHERE attendance_id=?", (attendance_id,))


# Reports used by ReportsFrame and based on the project's report requirements.
def report_student_list():
    return get_all_students()


def report_academic_performance():
    return _execute(f"""SELECT students.first_name || ' ' || students.last_name AS Student,
        classes.class_name AS Class, classes.grade_level AS GradeLevel,
        {SUBJECT_LABEL} AS Subject, marks.term AS Term,
        ROUND(marks.score,1) AS Score
        FROM marks JOIN enrollment ON marks.enrollment_id=enrollment.enrollment_id
        JOIN students ON enrollment.student_id=students.student_id
        LEFT JOIN classes ON students.class_id=classes.class_id
        JOIN subjects ON enrollment.subject_id=subjects.subject_id
        ORDER BY students.last_name, students.first_name, {SUBJECT_LABEL}, marks.term""", fetch=True)


def report_attendance():
    return _execute("""SELECT students.first_name || ' ' || students.last_name AS Student,
        SUM(CASE WHEN attendance.status='Present' THEN 1 ELSE 0 END) AS Present,
        SUM(CASE WHEN attendance.status='Absent' THEN 1 ELSE 0 END) AS Absent,
        SUM(CASE WHEN attendance.status='Late' THEN 1 ELSE 0 END) AS Late,
        COUNT(attendance.attendance_id) AS TotalRecords
        FROM attendance JOIN students ON attendance.student_id=students.student_id
        GROUP BY students.student_id ORDER BY students.last_name""", fetch=True)


def report_students_by_class():
    return _execute("""SELECT classes.class_name AS Class, classes.grade_level AS GradeLevel,
        COUNT(students.student_id) AS StudentCount
        FROM classes LEFT JOIN students ON students.class_id=classes.class_id
        GROUP BY classes.class_id, classes.class_name, classes.grade_level
        ORDER BY classes.class_name""", fetch=True)


def report_teacher_subject():
    return _execute(f"""SELECT teachers.first_name || ' ' || teachers.last_name AS Teacher,
        COALESCE(GROUP_CONCAT({SUBJECT_LABEL}, ', '),'(none)') AS SubjectsTaught
        FROM teachers LEFT JOIN teacher_subject ON teacher_subject.teacher_id=teachers.teacher_id
        LEFT JOIN subjects ON subjects.subject_id=teacher_subject.subject_id
        GROUP BY teachers.teacher_id ORDER BY teachers.last_name""", fetch=True)


def report_subject_performance():
    return _execute(f"""SELECT {SUBJECT_LABEL} AS Subject,
        COUNT(marks.mark_id) AS NumberOfStudents,
        ROUND(AVG(marks.score),1) AS AverageMark,
        MAX(marks.score) AS HighestMark, MIN(marks.score) AS LowestMark
        FROM subjects LEFT JOIN enrollment ON enrollment.subject_id=subjects.subject_id
        LEFT JOIN marks ON marks.enrollment_id=enrollment.enrollment_id
        GROUP BY subjects.subject_id, subjects.subject_name ORDER BY subjects.subject_name""", fetch=True)


def report_attendance_summary():
    return _execute("""SELECT students.student_id, students.first_name, students.last_name,
        classes.class_name, COUNT(attendance.attendance_id) AS total_attendance_records,
        SUM(CASE WHEN attendance.status='Present' THEN 1 ELSE 0 END) AS days_present,
        SUM(CASE WHEN attendance.status='Absent' THEN 1 ELSE 0 END) AS days_absent
        FROM students JOIN classes ON students.class_id=classes.class_id
        LEFT JOIN attendance ON students.student_id=attendance.student_id
        GROUP BY students.student_id, students.first_name, students.last_name, classes.class_name
        ORDER BY students.student_id""", fetch=True)


def report_students_per_grade():
    return _execute("""SELECT classes.grade_level AS Grade, COUNT(students.student_id) AS NumberOfStudents
        FROM classes LEFT JOIN students ON students.class_id=classes.class_id
        GROUP BY classes.grade_level ORDER BY classes.grade_level""", fetch=True)


def list_all_tables():
    rows = _execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name", fetch=True)
    return [r[0] for r in rows]


def _safe_identifier(value):
    safe = "".join(c for c in value if c.isalnum() or c == "_")
    if not safe:
        raise ValueError("Invalid table or column name")
    return safe


def create_dynamic_table(table_name, columns):
    safe_table = _safe_identifier(table_name)
    definitions=[]
    primary=[]
    for name,col_type,is_pk in columns:
        safe_col=_safe_identifier(name)
        definitions.append(f'"{safe_col}" {col_type}')
        if is_pk:
            primary.append(f'"{safe_col}"')
    if primary:
        definitions.append(f'PRIMARY KEY ({", ".join(primary)})')
    _execute(f'CREATE TABLE "{safe_table}" ({", ".join(definitions)})')


def drop_dynamic_table(table_name):
    _execute(f'DROP TABLE "{_safe_identifier(table_name)}"')


def get_table_columns(table_name):
    return _execute(f'PRAGMA table_info("{_safe_identifier(table_name)}")', fetch=True)


def get_table_rows(table_name):
    return _execute(f'SELECT * FROM "{_safe_identifier(table_name)}" ORDER BY 1', fetch=True)


def insert_into_table(table_name,column_values:dict):
    safe_table=_safe_identifier(table_name)
    safe_cols=[_safe_identifier(c) for c in column_values]
    cols=", ".join(f'"{c}"' for c in safe_cols)
    placeholders=", ".join("?" for _ in safe_cols)
    _execute(f'INSERT INTO "{safe_table}" ({cols}) VALUES ({placeholders})', list(column_values.values()))


def delete_from_table(table_name,pk_column,pk_value):
    _execute(f'DELETE FROM "{_safe_identifier(table_name)}" WHERE "{_safe_identifier(pk_column)}"=?', (pk_value,))
