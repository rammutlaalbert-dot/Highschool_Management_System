"""Backend/data-access package for the High School Management System."""
