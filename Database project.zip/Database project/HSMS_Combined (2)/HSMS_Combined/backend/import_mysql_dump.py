"""Import the phpMyAdmin/MariaDB dump (data/mydb.sql) into the app's SQLite database.

Usage (from the project root):
    python -m backend.import_mysql_dump                # data/mydb.sql -> school.db (rebuilt)
    python -m backend.import_mysql_dump other.sql

The MySQL schema and the app schema are not identical, so the data is mapped:

  MySQL table       -> app table         notes
  ----------------    -----------------  ------------------------------------------------
  teacher           -> teachers          surname -> last_name, speciality -> specialty
  class             -> classes           name "A" + grade 8 -> "8A" / "Grade 8"; year kept
  student           -> students          unchanged
  subjects          -> subjects          grade and lead teacher kept as extra columns
  teacher_subject   -> teacher_subject   surrogate id dropped, duplicate pairs merged
  users             -> users             role "Admin" -> "Administrator"; teacher link kept
  enrollment        -> class_enrollment  student-in-class-for-year (with status)
  marks             -> enrollment+marks  each (student, subject) becomes a subject
                                         enrollment; final_mark -> score, term "Final",
                                         test_mark / exam_mark kept
  attendance        -> attendance        attendance_status -> status

The dump has no homeroom teachers; assign_homeroom_teachers() derives one per class.
"""
import os
import re
import sqlite3
import sys

from . import data_access as db

DEFAULT_DUMP = os.path.join(db.BASE_DIR, "data", "mydb.sql")
ROLE_MAP = {"Admin": "Administrator", "Administrator": "Administrator",
            "Teacher": "Teacher", "Principal": "Principal"}


def _load_dump(sql_text):
    """Load every CREATE/INSERT from the dump into an in-memory scratch database."""
    scratch = sqlite3.connect(":memory:")
    for name, body in re.findall(r"CREATE TABLE `(\w+)` \((.*?)\) ENGINE", sql_text, re.S):
        cols = [re.match(r"\s*`(\w+)`", line).group(1)
                for line in body.split("\n") if line.strip().startswith("`")]
        scratch.execute(f"CREATE TABLE {name} ({', '.join(cols)})")
    for m in re.finditer(r"INSERT INTO `(\w+)` \(.*?\) VALUES\n(.*?);\n", sql_text, re.S):
        scratch.executescript(f"INSERT INTO {m.group(1)} VALUES\n{m.group(2)};")
    return scratch


def assign_homeroom_teachers(cur):
    """The dump has no homeroom teachers, so give every class one, derived from the data.

    A class in grade G may only get a teacher who teaches a Grade G subject (via
    teacher_subject or as the subject's lead teacher), each teacher is used for at most one
    class, and teachers who teach more of that grade's subjects are preferred. Purely a
    starting point - change any of them from the Classes screen.
    """
    import numpy as np
    from scipy.optimize import linear_sum_assignment

    classes = cur.execute("SELECT class_id, grade_level FROM classes ORDER BY class_id").fetchall()
    teachers = [r[0] for r in cur.execute("SELECT teacher_id FROM teachers ORDER BY teacher_id")]
    load = {}
    for tid, grade, n in cur.execute(
            """SELECT t, g, COUNT(DISTINCT sid) FROM (
                   SELECT ts.teacher_id t, s.grade g, s.subject_id sid
                     FROM teacher_subject ts JOIN subjects s ON s.subject_id=ts.subject_id
                   UNION
                   SELECT teacher_id, grade, subject_id FROM subjects WHERE teacher_id IS NOT NULL)
               GROUP BY t, g"""):
        load[(tid, f"Grade {grade}")] = n
    BIG = 10_000
    cost = np.full((len(classes), len(teachers)), BIG)
    for i, (_, grade_level) in enumerate(classes):
        for j, tid in enumerate(teachers):
            n = load.get((tid, grade_level), 0)
            if n:
                cost[i, j] = -n
    rows, cols = linear_sum_assignment(cost)
    assigned = 0
    for i, j in zip(rows, cols):
        if cost[i, j] < BIG:
            cur.execute("UPDATE classes SET class_teacher_id=? WHERE class_id=?",
                        (teachers[j], classes[i][0]))
            assigned += 1
    return assigned


def import_dump(sql_path=DEFAULT_DUMP, replace=True):
    with open(sql_path, encoding="utf8") as f:
        src = _load_dump(f.read())

    if replace and os.path.exists(db.DB_FILE):
        os.remove(db.DB_FILE)
    db.initialise_database()

    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM users")          # drop the seeded demo logins; dump users replace them
    q = lambda sql: src.execute(sql).fetchall()
    stats = {}

    cur.executemany("INSERT INTO teachers (teacher_id,first_name,last_name,phone,email,specialty) VALUES (?,?,?,?,?,?)",
                    q("SELECT teacher_id,first_name,surname,phone,email,speciality FROM teacher"))
    stats["teachers"] = len(q("SELECT 1 FROM teacher"))

    cur.executemany("INSERT INTO classes (class_id,class_name,grade_level,class_teacher_id,current_year) VALUES (?,?,?,?,?)",
                    [(cid, f"{grade}{name}", f"Grade {grade}", None, year)
                     for cid, name, grade, year in q("SELECT class_id,class_name,grade,current_year FROM class")])
    stats["classes"] = len(q("SELECT 1 FROM class"))

    cur.executemany("INSERT INTO students (student_id,first_name,last_name,date_of_birth,gender,class_id,parent_contact,address) VALUES (?,?,?,?,?,?,?,?)",
                    q("SELECT student_id,first_name,last_name,date_of_birth,gender,class_id,parent_contact,address FROM student"))
    stats["students"] = len(q("SELECT 1 FROM student"))

    cur.executemany("INSERT INTO subjects (subject_id,subject_name,grade,teacher_id) VALUES (?,?,?,?)",
                    q("SELECT subject_id,subject_name,grade,teacher_id FROM subjects"))
    stats["subjects"] = len(q("SELECT 1 FROM subjects"))

    ts = q("SELECT DISTINCT teacher_id,subject_id FROM teacher_subject")
    cur.executemany("INSERT INTO teacher_subject (teacher_id,subject_id) VALUES (?,?)", ts)
    stats["teacher_subject"] = len(ts)
    stats["teacher_subject_duplicates_merged"] = len(q("SELECT 1 FROM teacher_subject")) - len(ts)

    users = [(uid, uname, pw, ROLE_MAP[role], tid)
             for uid, uname, pw, role, tid in q("SELECT user_id,username,password,role,teacher_id FROM users")]
    cur.executemany("INSERT INTO users (user_id,username,password,role,teacher_id) VALUES (?,?,?,?,?)", users)
    stats["users"] = len(users)

    cur.executemany("INSERT INTO class_enrollment (class_enrollment_id,student_id,class_id,enrollment_year,enrollment_status) VALUES (?,?,?,?,?)",
                    q("SELECT enrollment_id,student_id,class_id,CAST(enrollment_year AS INTEGER),enrollment_status FROM enrollment"))
    stats["class_enrollment"] = len(q("SELECT 1 FROM enrollment"))

    # Marks in the dump are per student+subject, the app hangs marks off an enrollment.
    year = {sid: str(y) for sid, y in q(
        "SELECT student_id, MAX(enrollment_year) FROM enrollment GROUP BY student_id")}
    default_year = str(q("SELECT MAX(current_year) FROM class")[0][0])
    pairs = q("SELECT DISTINCT student_id,subject_id FROM marks ORDER BY student_id,subject_id")
    enr_id = {}
    for sid, subj in pairs:
        cur.execute("INSERT INTO enrollment (student_id,subject_id,academic_year) VALUES (?,?,?)",
                    (sid, subj, year.get(sid, default_year)))
        enr_id[(sid, subj)] = cur.lastrowid
    stats["subject_enrollments_created"] = len(pairs)

    marks = q("SELECT mark_id,student_id,subject_id,test_mark,exam_mark,final_mark FROM marks")
    cur.executemany("INSERT INTO marks (mark_id,enrollment_id,term,score,test_mark,exam_mark) VALUES (?,?,?,?,?,?)",
                    [(mid, enr_id[(sid, subj)], "Final", final, test, exam)
                     for mid, sid, subj, test, exam, final in marks])
    stats["marks"] = len(marks)

    cur.executemany("INSERT INTO attendance (attendance_id,student_id,attendance_date,status) VALUES (?,?,?,?)",
                    q("SELECT attendance_id,student_id,attendance_date,attendance_status FROM attendance"))
    stats["attendance"] = len(q("SELECT 1 FROM attendance"))

    stats["homeroom_teachers_assigned"] = assign_homeroom_teachers(cur)

    conn.commit()
    bad = cur.execute("PRAGMA foreign_key_check").fetchall()
    conn.close()
    stats["foreign_key_problems"] = len(bad)
    return stats


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_DUMP
    for key, value in import_dump(path).items():
        print(f"{key:36s} {value}")
    print("Database written to", db.DB_FILE)
