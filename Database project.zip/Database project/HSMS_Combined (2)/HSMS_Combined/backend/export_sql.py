"""Write the current school.db out as plain SQL scripts (CREATE TABLE + INSERT statements).

    python -m backend.export_sql

Produces, in data/:
    hsms_sqlite.sql   for the app itself (SQLite) - load with  python load_sql.py
    hsms_mysql.sql    same data for MySQL / MariaDB (Workbench, phpMyAdmin)
"""
import os
import sqlite3

from . import data_access as db

# parents first, so every INSERT satisfies its foreign keys
ORDER = ["teachers", "classes", "students", "subjects", "teacher_subject", "users",
         "class_enrollment", "enrollment", "marks", "attendance"]

MYSQL_DDL = {
"teachers": """CREATE TABLE `teachers` (
  `teacher_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `specialty` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"classes": """CREATE TABLE `classes` (
  `class_id` INT NOT NULL AUTO_INCREMENT,
  `class_name` VARCHAR(20) NOT NULL,
  `grade_level` VARCHAR(20) NOT NULL,
  `class_teacher_id` INT DEFAULT NULL,
  `current_year` INT DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  CONSTRAINT `classes_fk_teacher` FOREIGN KEY (`class_teacher_id`) REFERENCES `teachers` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"students": """CREATE TABLE `students` (
  `student_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `date_of_birth` DATE DEFAULT NULL,
  `gender` VARCHAR(20) DEFAULT NULL,
  `class_id` INT DEFAULT NULL,
  `parent_contact` VARCHAR(20) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  CONSTRAINT `students_fk_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"subjects": """CREATE TABLE `subjects` (
  `subject_id` INT NOT NULL AUTO_INCREMENT,
  `subject_name` VARCHAR(100) NOT NULL,
  `grade` INT DEFAULT NULL,
  `teacher_id` INT DEFAULT NULL,
  PRIMARY KEY (`subject_id`),
  CONSTRAINT `subjects_fk_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"teacher_subject": """CREATE TABLE `teacher_subject` (
  `teacher_id` INT NOT NULL,
  `subject_id` INT NOT NULL,
  PRIMARY KEY (`teacher_id`, `subject_id`),
  CONSTRAINT `ts_fk_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE,
  CONSTRAINT `ts_fk_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"users": """CREATE TABLE `users` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL,
  `teacher_id` INT DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `users_fk_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE SET NULL,
  CONSTRAINT `users_role_chk` CHECK (`role` IN ('Administrator','Teacher','Principal'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"class_enrollment": """CREATE TABLE `class_enrollment` (
  `class_enrollment_id` INT NOT NULL AUTO_INCREMENT,
  `student_id` INT NOT NULL,
  `class_id` INT NOT NULL,
  `enrollment_year` INT NOT NULL,
  `enrollment_status` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`class_enrollment_id`),
  CONSTRAINT `ce_fk_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `ce_fk_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"enrollment": """CREATE TABLE `enrollment` (
  `enrollment_id` INT NOT NULL AUTO_INCREMENT,
  `student_id` INT NOT NULL,
  `subject_id` INT NOT NULL,
  `academic_year` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  CONSTRAINT `enr_fk_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `enr_fk_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"marks": """CREATE TABLE `marks` (
  `mark_id` INT NOT NULL AUTO_INCREMENT,
  `enrollment_id` INT NOT NULL,
  `term` VARCHAR(20) NOT NULL,
  `score` DECIMAL(5,2) NOT NULL,
  `test_mark` DECIMAL(5,2) DEFAULT NULL,
  `exam_mark` DECIMAL(5,2) DEFAULT NULL,
  PRIMARY KEY (`mark_id`),
  CONSTRAINT `marks_fk_enrollment` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollment` (`enrollment_id`) ON DELETE CASCADE,
  CONSTRAINT `marks_score_chk` CHECK (`score` >= 0 AND `score` <= 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
"attendance": """CREATE TABLE `attendance` (
  `attendance_id` INT NOT NULL AUTO_INCREMENT,
  `student_id` INT NOT NULL,
  `attendance_date` DATE NOT NULL,
  `status` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`attendance_id`),
  CONSTRAINT `att_fk_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `att_status_chk` CHECK (`status` IN ('Present','Absent','Late'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""",
}


def _lit(v):
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return repr(v)
    return "'" + str(v).replace("'", "''") + "'"


def _inserts(conn, table, quote):
    cols = [r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')]
    order = ", ".join(cols)
    rows = conn.execute(f'SELECT {", ".join(cols)} FROM "{table}" ORDER BY {order}').fetchall()
    head = f"INSERT INTO {quote}{table}{quote} ({', '.join(quote + c + quote for c in cols)}) VALUES\n"
    body = ",\n".join("(" + ", ".join(_lit(v) for v in r) + ")" for r in rows)
    return f"-- {table}: {len(rows)} rows\n{head}{body};\n" if rows else ""


def export(out_dir=None):
    out_dir = out_dir or os.path.join(db.BASE_DIR, "data")
    conn = sqlite3.connect(db.DB_FILE)

    # ---- SQLite (the app's own schema, taken straight from school.db)
    lines = ["-- High School Management System - schema and data (SQLite)",
             "-- Load with:  python load_sql.py   (or  sqlite3 school.db < data/hsms_sqlite.sql)",
             "PRAGMA foreign_keys = OFF;", "BEGIN TRANSACTION;", ""]
    for t in reversed(ORDER):
        lines.append(f'DROP TABLE IF EXISTS "{t}";')
    lines.append("")
    for t in ORDER:
        ddl = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone()[0]
        lines.append(ddl.replace("CREATE TABLE IF NOT EXISTS", "CREATE TABLE") + ";\n")
    for t in ORDER:
        lines.append(_inserts(conn, t, '"'))
    lines += ["COMMIT;", "PRAGMA foreign_keys = ON;", ""]
    with open(os.path.join(out_dir, "hsms_sqlite.sql"), "w", encoding="utf8", newline="\n") as f:
        f.write("\n".join(lines))

    # ---- MySQL / MariaDB
    lines = ["-- High School Management System - schema and data (MySQL / MariaDB)",
             "-- In Workbench: File > Run SQL Script.  Creates and fills the database `hsms`.",
             "CREATE DATABASE IF NOT EXISTS `hsms` DEFAULT CHARACTER SET utf8mb4;", "USE `hsms`;",
             "SET FOREIGN_KEY_CHECKS = 0;", "SET NAMES utf8mb4;", ""]
    for t in reversed(ORDER):
        lines.append(f"DROP TABLE IF EXISTS `{t}`;")
    lines.append("")
    for t in ORDER:
        lines.append(MYSQL_DDL[t] + "\n")
    for t in ORDER:
        lines.append(_inserts(conn, t, "`"))
    lines += ["SET FOREIGN_KEY_CHECKS = 1;", ""]
    with open(os.path.join(out_dir, "hsms_mysql.sql"), "w", encoding="utf8", newline="\n") as f:
        f.write("\n".join(lines))
    conn.close()


if __name__ == "__main__":
    export()
    print("Wrote data/hsms_sqlite.sql and data/hsms_mysql.sql")
