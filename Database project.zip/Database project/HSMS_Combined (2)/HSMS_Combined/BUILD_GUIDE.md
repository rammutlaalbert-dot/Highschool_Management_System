# How This Was Built — Step by Step

## 1. Read the spec and listed every table it named
`users`, `students`, `teachers`, `classes`, `subjects`, `teacher_subject`,
`enrollment`, `marks`, `attendance` — 9 tables, not a guess. Two of them
(`teacher_subject`, `enrollment`) are pure junction tables resolving
many-to-many relationships (a teacher teaches many subjects and a
subject has many teachers; a student takes many subjects and a subject
has many students).

## 2. Designed the schema on paper before touching code
Key decision: **marks reference `enrollment`, not student+subject
directly.** Since enrollment already links a student to a subject for
a year, having marks point at enrollment_id keeps the design normalized
— no duplicate student_id/subject_id columns sitting in two tables.

## 3. Built `data_access.py` completely before any GUI
One function per operation per table, plus the 5 report functions as
plain SQL `JOIN`/`GROUP BY` queries returning rows the GUI can just
drop into a table widget. Tested every function from a plain Python
script (no GUI) before writing a single Tkinter widget — this caught
every foreign-key ordering issue immediately.

## 4. Added role-based access as a first-class concept
Two mechanisms, both driven by `controller.current_user["role"]`:
- `TILES_BY_ROLE` in `dashboard_frame.py` — controls what's navigable.
- `can_edit()` / `set_buttons_state()` in `gui/widgets.py` — controls
  what's editable on a screen you can see. A Teacher can *view* the
  Students screen but its Add/Update/Delete buttons are disabled.

## 5. Built one screen per module, reusing a shared header helper
`gui/widgets.py` has `build_header()` so every screen gets the same
"< Back" + title bar without repeating that code 12 times.

## 6. Built the Reports screen last, once every table had data to report on
Each report is one SQL query wrapped in a Python function
(`report_student_list`, `report_academic_performance`, etc.) — the GUI
just calls the function and dumps the rows into a Treeview. Added CSV
export since it's an easy "extra mile" win.

## 7. Built Manage Tables (Administrator-only) for the dynamic
add/remove-table requirement
This uses `sqlite_master` / `PRAGMA table_info` to list and inspect
tables at runtime, and plain `CREATE TABLE` / `DROP TABLE` built from
whatever columns the Administrator defines in the form — this is how
the spec's "Add a new table" / "Remove a table" requirement is met for
tables beyond the 9 fixed ones.

## 8. Tested the whole thing end-to-end with real data
Created a teacher, a class, two students, two subjects, assigned a
teacher to a subject, enrolled both students, added marks and
attendance, then ran all 5 reports and both logins-per-role checks
before calling it done.

---

## YouTube tutorials matching each step

**Multi-page Tkinter navigation:**
- Switch Between Pages — Multi Page Tkinter, step-by-step
  https://www.youtube.com/watch?v=qw_XHRJP-vc

**Treeview + SQLite CRUD:**
- Build a CRM Tool with Treeview and Database (Codemy #172)
  https://tkinter.com/build-a-crm-tool-with-treeview-and-database-python-tkinter-gui-tutorial-172/
- Connect Treeview to Database (Codemy #174)
  https://www.youtube.com/watch?v=pSXlKihUTlU
- Add New Database Record with Treeview (Codemy #177)
  https://www.youtube.com/watch?v=zDDkNDg_y3I

**Role-based / multi-user login patterns:**
- Search "Tkinter login system with roles sqlite" for several worked
  examples — the pattern is the same one used here: check the role
  after login, then show/hide UI based on it.

**Git & GitHub for a team project:**
- GitHub's own "Hello World" walkthrough
  https://docs.github.com/get-started/quickstart/hello-world
- GitHub for Beginners video series (official channel)
  https://www.youtube.com/@GitHubGuides

---

## GitHub setup notes for your group

- `.gitignore` excludes `__pycache__/` and the local `school.db` —
  everyone generates their own test database locally.
- Suggested workflow: one branch per person (`interface`, `backend`,
  `database`), pull requests into `main`, pull before you push.
- Since `data_access.py` is the shared contract between Interface,
  Backend and Database, agree on function names as a group **before**
  anyone starts editing it — that's the most likely merge-conflict spot.
