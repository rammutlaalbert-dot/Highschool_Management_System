from backend import data_access as db

if __name__ == "__main__":
    db.initialise_database()
    print("High School Management System backend is ready.")
    print("Database:", db.DB_FILE)
    print("Tables:", ", ".join(db.list_all_tables()))
