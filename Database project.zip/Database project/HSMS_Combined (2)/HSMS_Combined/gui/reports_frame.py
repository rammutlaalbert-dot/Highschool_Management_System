import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import filedialog
import csv
import data_access as db
from gui.widgets import build_header

GOLD = "#B8860B"


class ReportsFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Reports")

        button_panel = tk.Frame(self, bg="white")
        button_panel.pack(fill="x", padx=20, pady=15)

        reports = [
            ("1. Student List", db.report_student_list,
             ["ID", "First", "Last", "DOB", "Gender", "Class", "Contact", "Address"]),
            ("2. Academic Performance", db.report_academic_performance,
             ["Student", "Class", "Grade Level", "Subject", "Term", "Score"]),
            ("3. Attendance", db.report_attendance,
             ["Student", "Present", "Absent", "Late", "Total Records"]),
            ("4. Students by Class", db.report_students_by_class,
             ["Class", "Grade Level", "Student Count"]),
            ("5. Teacher-Subject", db.report_teacher_subject,
             ["Teacher", "Subjects Taught"]),
            ("6. Subject Performance", db.report_subject_performance,
             ["Subject", "Marks Recorded", "Average", "Highest", "Lowest"]),
            ("7. Attendance Summary", db.report_attendance_summary,
             ["ID", "First", "Last", "Class", "Total Records", "Days Present", "Days Absent"]),
            ("8. Students per Grade", db.report_students_per_grade,
             ["Grade", "Number of Students"]),
        ]

        for i, (label, fn, headers) in enumerate(reports):
            tk.Button(button_panel, text=label, bg=GOLD, fg="white", width=24,
                      command=lambda f=fn, h=headers, l=label: self.run_report(f, h, l)
                      ).grid(row=i // 4, column=i % 4, padx=4, pady=3)

        self.title_label = tk.Label(self, text="Select a report above", bg="white",
                                     font=("Segoe UI", 13, "bold"))
        self.title_label.pack(anchor="w", padx=20, pady=(10, 0))

        self.tree = ttk.Treeview(self, show="headings", height=16)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        tk.Button(self, text="Export to CSV", command=self.export_csv).pack(anchor="w", padx=20, pady=(0, 10))

        self._current_rows = []
        self._current_headers = []

    def run_report(self, fn, headers, title):
        self.title_label.config(text=title)
        rows = fn()
        self._current_rows = rows
        self._current_headers = headers

        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = headers
        for h in headers:
            self.tree.heading(h, text=h)
            self.tree.column(h, width=120)
        for row in rows:
            self.tree.insert("", "end", values=row)

    def export_csv(self):
        if not self._current_rows:
            messagebox.showinfo("No report", "Run a report first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                             filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(self._current_headers)
            writer.writerows(self._current_rows)
        messagebox.showinfo("Exported", "Report exported successfully.")

    def on_show(self):
        pass                                                 
