import tkinter as tk

DARK = "#1A1A1A"


TILES_BY_ROLE = {
    "Administrator": [
        ("Users", "UsersFrame", "#5D4037"),
        ("Students", "StudentsFrame", "#B8860B"),
        ("Teachers", "TeachersFrame", "#2E7D32"),
        ("Classes", "ClassesFrame", "#00838F"),
        ("Subjects", "SubjectsFrame", "#1565C0"),
        ("Teacher-Subject", "TeacherSubjectFrame", "#6A1B9A"),
        ("Enrollment", "EnrollmentFrame", "#EF6C00"),
        ("Marks", "MarksFrame", "#8E24AA"),
        ("Attendance", "AttendanceFrame", "#C62828"),
        ("Reports", "ReportsFrame", "#37474F"),
        ("Manage Tables", "ManageTablesFrame", "#455A64"),
    ],
    "Teacher": [
        ("Students", "StudentsFrame", "#B8860B"),
        ("Enrollment", "EnrollmentFrame", "#EF6C00"),
        ("Marks", "MarksFrame", "#8E24AA"),
        ("Attendance", "AttendanceFrame", "#C62828"),
        ("Reports", "ReportsFrame", "#37474F"),
    ],
    "Principal": [
        ("Students", "StudentsFrame", "#B8860B"),
        ("Teachers", "TeachersFrame", "#2E7D32"),
        ("Classes", "ClassesFrame", "#00838F"),
        ("Subjects", "SubjectsFrame", "#1565C0"),
        ("Teacher-Subject", "TeacherSubjectFrame", "#6A1B9A"),
        ("Enrollment", "EnrollmentFrame", "#EF6C00"),
        ("Marks", "MarksFrame", "#8E24AA"),
        ("Attendance", "AttendanceFrame", "#C62828"),
        ("Reports", "ReportsFrame", "#37474F"),
    ],
}


class DashboardFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller

        self.header = tk.Frame(self, bg=DARK, height=70)
        self.header.pack(fill="x")
        self.welcome_label = tk.Label(self.header, text="Welcome", bg=DARK, fg="white",
                                       font=("Segoe UI", 16, "bold"))
        self.welcome_label.pack(side="left", padx=20, pady=15)

        tk.Button(self.header, text="Log Out", command=self.logout, bg=DARK, fg="white",
                  bd=0, activebackground="#333333").pack(side="right", padx=20, pady=20)

        self.body = tk.Frame(self, bg="white")
        self.body.pack(expand=True, fill="both", padx=40, pady=30)

    def on_show(self):
        for widget in self.body.winfo_children():
            widget.destroy()

        user = self.controller.current_user
        if not user:
            return
        self.welcome_label.config(text=f"Welcome, {user['username']} ({user['role']})")

        tiles = TILES_BY_ROLE.get(user["role"], [])
        for i, (label, frame_name, color) in enumerate(tiles):
            tk.Button(self.body, text=label, font=("Segoe UI", 12, "bold"), bg=color, fg="white",
                      width=18, height=3, bd=0,
                      command=lambda f=frame_name: self.controller.show_frame(f)
                      ).grid(row=i // 4, column=i % 4, padx=12, pady=12)

    def logout(self):
        self.controller.current_user = None
        self.controller.show_frame("LoginFrame")
