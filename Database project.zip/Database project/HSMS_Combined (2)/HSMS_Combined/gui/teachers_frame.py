import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class TeachersFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        self.selected_id = None
        build_header(self, controller, "Teachers")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)
        labels = ["First Name", "Last Name", "Phone", "Email", "Specialty"]
        self.entries = {}
        for i, label in enumerate(labels):
            tk.Label(form, text=label, bg="white", font=("Segoe UI", 9)).grid(row=0, column=i, sticky="w", padx=4)
            entry = ttk.Entry(form, width=18)
            entry.grid(row=1, column=i, padx=4)
            self.entries[label] = entry

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Add Teacher", bg=GOLD, fg="white", command=self.add_teacher)
        self.update_btn = tk.Button(btn_frame, text="Update Selected", bg="#1565C0", fg="white",
                                     command=self.update_teacher)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_teacher)
        self.clear_btn = tk.Button(btn_frame, text="Clear Form", command=self.clear_form)
        self.add_btn.pack(side="left", padx=4)
        self.update_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)
        self.clear_btn.pack(side="left", padx=4)

        columns = ("id", "first", "last", "phone", "email", "specialty")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14)
        for col, head in zip(columns, ["ID", "First Name", "Last Name", "Phone", "Email", "Specialty"]):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=110)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)
        self.tree.bind("<<TreeviewSelect>>", self.on_row_select)

        self.refresh()

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for teacher in db.get_all_teachers():
            self.tree.insert("", "end", values=teacher)

    def on_row_select(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        values = self.tree.item(selected[0], "values")
        self.selected_id = values[0]
        for field, value in zip(["First Name", "Last Name", "Phone", "Email", "Specialty"], values[1:]):
            self.entries[field].delete(0, tk.END)
            self.entries[field].insert(0, value)

    def _collect_form(self):
        keys = ["First Name", "Last Name", "Phone", "Email", "Specialty"]
        return [self.entries[k].get().strip() for k in keys]

    def add_teacher(self):
        values = self._collect_form()
        if not values[0] or not values[1]:
            messagebox.showwarning("Missing info", "First and last name are required.")
            return
        db.add_teacher(*values)
        self.refresh()
        self.clear_form()

    def update_teacher(self):
        if not self.selected_id:
            messagebox.showwarning("No selection", "Select a teacher in the table first.")
            return
        db.update_teacher(self.selected_id, *self._collect_form())
        self.refresh()
        self.clear_form()

    def delete_teacher(self):
        if not self.selected_id:
            messagebox.showwarning("No selection", "Select a teacher in the table first.")
            return
        if messagebox.askyesno("Confirm delete", "Delete the selected teacher?"):
            db.delete_teacher(self.selected_id)
            self.refresh()
            self.clear_form()

    def clear_form(self):
        self.selected_id = None
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.tree.selection_remove(self.tree.selection())

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["TeachersFrame"])
        set_buttons_state([self.add_btn, self.update_btn, self.delete_btn], editable)
