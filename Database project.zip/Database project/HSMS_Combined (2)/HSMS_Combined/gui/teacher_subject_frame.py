import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class TeacherSubjectFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Teacher \u2192 Subject Assignment")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)

        tk.Label(form, text="Teacher", bg="white", font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", padx=4)
        self.teacher_combo = ttk.Combobox(form, width=25, state="readonly")
        self.teacher_combo.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Subject", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.subject_combo = ttk.Combobox(form, width=25, state="readonly")
        self.subject_combo.grid(row=1, column=1, padx=4)

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Assign", bg=GOLD, fg="white", command=self.assign)
        self.delete_btn = tk.Button(btn_frame, text="Remove Selected", bg="#C62828", fg="white",
                                     command=self.remove_assignment)
        self.add_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)

        columns = ("teacher_id", "teacher", "subject_id", "subject")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14,
                                  displaycolumns=("teacher", "subject"))
        for col, head in zip(columns, ["TeacherID", "Teacher", "SubjectID", "Subject"]):
            self.tree.heading(col, text=head)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.teacher_lookup = {}
        self.subject_lookup = {}
        self.refresh()

    def refresh(self):
        self.teacher_lookup = {name: tid for tid, name in db.get_teacher_choices()}
        self.teacher_combo["values"] = list(self.teacher_lookup.keys())
        self.subject_lookup = {name: sid for sid, name in db.get_subject_choices()}
        self.subject_combo["values"] = list(self.subject_lookup.keys())

        for row in self.tree.get_children():
            self.tree.delete(row)
        for row in db.get_all_teacher_subjects():
            self.tree.insert("", "end", values=row)

    def assign(self):
        teacher_name = self.teacher_combo.get()
        subject_name = self.subject_combo.get()
        if not (teacher_name and subject_name):
            messagebox.showwarning("Missing info", "Select both a teacher and a subject.")
            return
        db.assign_teacher_to_subject(self.teacher_lookup[teacher_name], self.subject_lookup[subject_name])
        self.refresh()

    def remove_assignment(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select an assignment in the table first.")
            return
        values = self.tree.item(selected[0], "values")
        teacher_id, subject_id = values[0], values[2]
        if messagebox.askyesno("Confirm remove", "Remove this teacher-subject assignment?"):
            db.remove_teacher_subject(teacher_id, subject_id)
            self.refresh()

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["TeacherSubjectFrame"])
        set_buttons_state([self.add_btn, self.delete_btn], editable)
