import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db

GOLD = "#B8860B"
DARK = "#1A1A1A"


class LoginFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller

        card = tk.Frame(self, bg="white")
        card.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(card, text="High School Management System", font=("Segoe UI", 18, "bold"),
                 bg="white", fg=DARK).pack(pady=(0, 5))
        tk.Label(card, text="Sign in to continue", font=("Segoe UI", 11),
                 bg="white", fg="#666666").pack(pady=(0, 20))

        tk.Label(card, text="Username", bg="white", anchor="w").pack(fill="x")
        self.username_entry = ttk.Entry(card, width=30)
        self.username_entry.pack(pady=(0, 10))

        tk.Label(card, text="Password", bg="white", anchor="w").pack(fill="x")
        self.password_entry = ttk.Entry(card, width=30, show="*")
        self.password_entry.pack(pady=(0, 20))
        self.password_entry.bind("<Return>", lambda e: self.attempt_login())

        tk.Button(card, text="Log In", bg=GOLD, fg="white", font=("Segoe UI", 11, "bold"),
                  width=25, command=self.attempt_login).pack(pady=(0, 5))

        tk.Label(card, text="Logins are stored in the users table\n"
                             "(e.g. admin, principal, teacher1 - teacher15).\n"
                             "See README.md for the credentials.",
                 bg="white", fg="#999999", font=("Segoe UI", 9), justify="left").pack(pady=(15, 0))

    def attempt_login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        result = db.verify_login(username, password)
        if result:
            user_id, role = result
            self.controller.current_user = {"id": user_id, "username": username, "role": role}
            self.password_entry.delete(0, tk.END)
            self.controller.show_frame("DashboardFrame")
        else:
            messagebox.showerror("Login failed", "Incorrect username or password.")
