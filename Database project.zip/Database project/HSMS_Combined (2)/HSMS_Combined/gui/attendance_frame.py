import tkinter as tk
from tkinter import ttk, messagebox
import datetime
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class AttendanceFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Attendance")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)

        tk.Label(form, text="Student", bg="white", font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", padx=4)
        self.student_combo = ttk.Combobox(form, width=22, state="readonly")
        self.student_combo.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Date (YYYY-MM-DD)", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.date_entry = ttk.Entry(form, width=15)
        self.date_entry.insert(0, datetime.date.today().isoformat())
        self.date_entry.grid(row=1, column=1, padx=4)

        tk.Label(form, text="Status", bg="white", font=("Segoe UI", 9)).grid(row=0, column=2, sticky="w", padx=4)
        self.status_combo = ttk.Combobox(form, width=15, state="readonly",
                                          values=["Present", "Absent", "Late", "Excused"])
        self.status_combo.grid(row=1, column=2, padx=4)

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Mark Attendance", bg=GOLD, fg="white", command=self.add_attendance)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_attendance)
        self.add_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)

        columns = ("id", "student", "date", "status")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14)
        for col, head in zip(columns, ["ID", "Student", "Date", "Status"]):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=150)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.student_lookup = {}
        self.refresh()

    def refresh(self):
        self.student_lookup = {name: sid for sid, name in db.get_student_choices()}
        self.student_combo["values"] = list(self.student_lookup.keys())

        for row in self.tree.get_children():
            self.tree.delete(row)
        for record in db.get_all_attendance():
            self.tree.insert("", "end", values=record)

    def add_attendance(self):
        student_name = self.student_combo.get()
        date = self.date_entry.get().strip()
        status = self.status_combo.get()
        if not (student_name and date and status):
            messagebox.showwarning("Missing info", "All fields are required.")
            return
        db.mark_attendance(self.student_lookup[student_name], date, status)
        self.refresh()

    def delete_attendance(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a record in the table first.")
            return
        attendance_id = self.tree.item(selected[0], "values")[0]
        if messagebox.askyesno("Confirm delete", "Delete the selected attendance record?"):
            db.delete_attendance(attendance_id)
            self.refresh()

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["AttendanceFrame"])
        set_buttons_state([self.add_btn, self.delete_btn], editable)
