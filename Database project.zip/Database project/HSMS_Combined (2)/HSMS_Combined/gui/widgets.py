import tkinter as tk

DARK = "#1A1A1A"


def build_header(parent, controller, title):
    header = tk.Frame(parent, bg=DARK, height=60)
    header.pack(fill="x")
    tk.Button(header, text="< Back", command=lambda: controller.show_frame("DashboardFrame"),
              bg=DARK, fg="white", bd=0).pack(side="left", padx=15, pady=15)
    tk.Label(header, text=title, bg=DARK, fg="white",
              font=("Segoe UI", 14, "bold")).pack(side="left", padx=10)
    return header


# Who may use the Add / Update / Delete buttons on each screen.
# Change a role here and it takes effect everywhere; the dashboard tiles are in dashboard_frame.py.
EDIT_ROLES = {
    "StudentsFrame":       ["Administrator", "Principal", "Teacher"],
    "TeachersFrame":       ["Administrator", "Principal"],
    "ClassesFrame":        ["Administrator", "Principal"],
    "SubjectsFrame":       ["Administrator", "Principal"],
    "TeacherSubjectFrame": ["Administrator", "Principal"],
    "EnrollmentFrame":     ["Administrator", "Principal", "Teacher"],
    "MarksFrame":          ["Administrator", "Principal", "Teacher"],
    "AttendanceFrame":     ["Administrator", "Principal", "Teacher"],
}


def can_edit(controller, allowed_roles):
    user = controller.current_user
    return bool(user and user["role"] in allowed_roles)


def set_buttons_state(buttons, enabled):
    state = "normal" if enabled else "disabled"
    for b in buttons:
        b.config(state=state)
