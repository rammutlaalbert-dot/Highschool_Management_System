import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class ClassesFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Classes")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)

        tk.Label(form, text="Class Name (e.g. 10A)", bg="white", font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", padx=4)
        self.name_entry = ttk.Entry(form, width=18)
        self.name_entry.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Grade Level", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.grade_combo = ttk.Combobox(form, width=16, state="readonly",
                                         values=[f"Grade {n}" for n in range(8, 13)])
        self.grade_combo.grid(row=1, column=1, padx=4)

        tk.Label(form, text="Homeroom Teacher", bg="white", font=("Segoe UI", 9)).grid(row=0, column=2, sticky="w", padx=4)
        self.teacher_combo = ttk.Combobox(form, width=22, state="readonly")
        self.teacher_combo.grid(row=1, column=2, padx=4)

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Add Class", bg=GOLD, fg="white", command=self.add_class)
        self.update_btn = tk.Button(btn_frame, text="Update Selected", bg="#2E7D32", fg="white",
                                     command=self.update_class)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_class)
        self.add_btn.pack(side="left", padx=4)
        self.update_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)

        columns = ("id", "name", "grade", "teacher")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14)
        for col, head in zip(columns, ["ID", "Class Name", "Grade Level", "Homeroom Teacher"]):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=150)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.teacher_lookup = {}
        self.refresh()

    def on_select(self, _event=None):
        selected = self.tree.selection()
        if not selected:
            return
        _, name, grade, teacher = self.tree.item(selected[0], "values")
        self.name_entry.delete(0, tk.END)
        self.name_entry.insert(0, name)
        self.grade_combo.set(grade)
        self.teacher_combo.set("" if teacher == "(none)" else teacher)

    def update_class(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a class in the table first.")
            return
        class_id = self.tree.item(selected[0], "values")[0]
        name = self.name_entry.get().strip()
        grade = self.grade_combo.get()
        if not name or not grade:
            messagebox.showwarning("Missing info", "Class name and grade level are required.")
            return
        db.update_class(class_id, name, grade, self.teacher_lookup.get(self.teacher_combo.get()))
        self.refresh()

    def refresh(self):
        self.teacher_lookup = {name: tid for tid, name in db.get_teacher_choices()}
        self.teacher_combo["values"] = list(self.teacher_lookup.keys())

        for row in self.tree.get_children():
            self.tree.delete(row)
        for class_row in db.get_all_classes():
            self.tree.insert("", "end", values=class_row)

    def add_class(self):
        name = self.name_entry.get().strip()
        grade = self.grade_combo.get()
        teacher_id = self.teacher_lookup.get(self.teacher_combo.get())
        if not name or not grade:
            messagebox.showwarning("Missing info", "Class name and grade level are required.")
            return
        db.add_class(name, grade, teacher_id)
        self.refresh()
        self.name_entry.delete(0, tk.END)
        self.grade_combo.set("")
        self.teacher_combo.set("")

    def delete_class(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a class in the table first.")
            return
        class_id = self.tree.item(selected[0], "values")[0]
        if messagebox.askyesno("Confirm delete", "Delete the selected class?"):
            db.delete_class(class_id)
            self.refresh()

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["ClassesFrame"])
        set_buttons_state([self.add_btn, self.update_btn, self.delete_btn], editable)
