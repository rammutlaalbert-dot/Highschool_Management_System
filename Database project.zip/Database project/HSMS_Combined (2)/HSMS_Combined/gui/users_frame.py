import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state

GOLD = "#B8860B"


class UsersFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Users (Login Management)")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)

        tk.Label(form, text="Username", bg="white", font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", padx=4)
        self.username_entry = ttk.Entry(form, width=20)
        self.username_entry.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Password", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.password_entry = ttk.Entry(form, width=20, show="*")
        self.password_entry.grid(row=1, column=1, padx=4)

        tk.Label(form, text="Role", bg="white", font=("Segoe UI", 9)).grid(row=0, column=2, sticky="w", padx=4)
        self.role_combo = ttk.Combobox(form, width=18, state="readonly", values=db.ROLES)
        self.role_combo.grid(row=1, column=2, padx=4)

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Add User", bg=GOLD, fg="white", command=self.add_user)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_user)
        self.add_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)

        columns = ("id", "username", "role")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14)
        for col, head in zip(columns, ["ID", "Username", "Role"]):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=150)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.refresh()

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for user in db.get_all_users():
            self.tree.insert("", "end", values=user)

    def add_user(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        role = self.role_combo.get()
        if not (username and password and role):
            messagebox.showwarning("Missing info", "Username, password and role are all required.")
            return
        try:
            db.add_user(username, password, role)
        except Exception as ex:
            messagebox.showerror("Error", f"Could not add user:\n{ex}")
            return
        self.refresh()
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)
        self.role_combo.set("")

    def delete_user(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a user in the table first.")
            return
        user_id = self.tree.item(selected[0], "values")[0]
        if messagebox.askyesno("Confirm delete", "Delete the selected user?"):
            db.delete_user(user_id)
            self.refresh()

    def on_show(self):
        self.refresh()

        set_buttons_state([self.add_btn, self.delete_btn],
                           can_edit(self.controller, ["Administrator"]))
