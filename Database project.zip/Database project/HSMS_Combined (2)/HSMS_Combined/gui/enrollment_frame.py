import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class EnrollmentFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Enrollment (Students \u2192 Subjects)")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)

        tk.Label(form, text="Student", bg="white", font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", padx=4)
        self.student_combo = ttk.Combobox(form, width=22, state="readonly")
        self.student_combo.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Subject", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.subject_combo = ttk.Combobox(form, width=20, state="readonly")
        self.subject_combo.grid(row=1, column=1, padx=4)

        tk.Label(form, text="Academic Year", bg="white", font=("Segoe UI", 9)).grid(row=0, column=2, sticky="w", padx=4)
        self.year_entry = ttk.Entry(form, width=12)
        self.year_entry.insert(0, "2026")
        self.year_entry.grid(row=1, column=2, padx=4)

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Enroll", bg=GOLD, fg="white", command=self.enroll)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_enrollment)
        self.add_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)

        columns = ("id", "student", "subject", "year")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14)
        for col, head in zip(columns, ["ID", "Student", "Subject", "Academic Year"]):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=150)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.student_lookup = {}
        self.subject_lookup = {}
        self.refresh()

    def refresh(self):
        self.student_lookup = {name: sid for sid, name in db.get_student_choices()}
        self.student_combo["values"] = list(self.student_lookup.keys())
        self.subject_lookup = {name: sid for sid, name in db.get_subject_choices()}
        self.subject_combo["values"] = list(self.subject_lookup.keys())

        for row in self.tree.get_children():
            self.tree.delete(row)
        for row in db.get_all_enrollments():
            self.tree.insert("", "end", values=row)

    def enroll(self):
        student_name = self.student_combo.get()
        subject_name = self.subject_combo.get()
        year = self.year_entry.get().strip()
        if not (student_name and subject_name and year):
            messagebox.showwarning("Missing info", "Student, subject and academic year are all required.")
            return
        db.enroll_student(self.student_lookup[student_name], self.subject_lookup[subject_name], year)
        self.refresh()

    def delete_enrollment(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select an enrollment record in the table first.")
            return
        enrollment_id = self.tree.item(selected[0], "values")[0]
        if messagebox.askyesno("Confirm delete", "Delete the selected enrollment? "
                                                  "(this also removes any marks linked to it)"):
            db.delete_enrollment(enrollment_id)
            self.refresh()

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["EnrollmentFrame"])
        set_buttons_state([self.add_btn, self.delete_btn], editable)
