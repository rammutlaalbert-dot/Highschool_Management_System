import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class SubjectsFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Subjects")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)
        tk.Label(form, text="Subject Name", bg="white", font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", padx=4)
        self.subject_entry = ttk.Entry(form, width=25)
        self.subject_entry.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Grade", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.grade_combo = ttk.Combobox(form, width=8, state="readonly", values=[str(n) for n in range(8, 13)])
        self.grade_combo.grid(row=1, column=1, padx=4)

        tk.Label(form, text="Lead Teacher", bg="white", font=("Segoe UI", 9)).grid(row=0, column=2, sticky="w", padx=4)
        self.teacher_combo = ttk.Combobox(form, width=24, state="readonly")
        self.teacher_combo.grid(row=1, column=2, padx=4)
        self.teacher_lookup = {}

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Add Subject", bg=GOLD, fg="white", command=self.add_subject)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_subject)
        self.add_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)

        columns = ("id", "name", "grade", "teacher")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14)
        for col, head in zip(columns, ["ID", "Subject Name", "Grade", "Lead Teacher"]):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=200 if col in ("name", "teacher") else 90)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.refresh()

    def refresh(self):
        self.teacher_lookup = {name: tid for tid, name in db.get_teacher_choices()}
        self.teacher_combo["values"] = list(self.teacher_lookup)
        for row in self.tree.get_children():
            self.tree.delete(row)
        for subject in db.get_all_subjects():
            self.tree.insert("", "end", values=subject)

    def add_subject(self):
        name = self.subject_entry.get().strip()
        if not name:
            messagebox.showwarning("Missing info", "Subject name is required.")
            return
        grade = self.grade_combo.get()
        teacher_id = self.teacher_lookup.get(self.teacher_combo.get())
        db.add_subject(name, int(grade) if grade else None, teacher_id)
        self.refresh()
        self.subject_entry.delete(0, tk.END)
        self.grade_combo.set("")
        self.teacher_combo.set("")

    def delete_subject(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a subject in the table first.")
            return
        subject_id = self.tree.item(selected[0], "values")[0]
        if messagebox.askyesno("Confirm delete", "Delete the selected subject?"):
            db.delete_subject(subject_id)
            self.refresh()

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["SubjectsFrame"])
        set_buttons_state([self.add_btn, self.delete_btn], editable)
