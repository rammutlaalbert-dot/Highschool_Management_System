import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class MarksFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Marks")

        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)

        tk.Label(form, text="Enrollment (Student - Subject)", bg="white", font=("Segoe UI", 9)).grid(
            row=0, column=0, sticky="w", padx=4)
        self.enrollment_combo = ttk.Combobox(form, width=35, state="readonly")
        self.enrollment_combo.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Term", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.term_combo = ttk.Combobox(form, width=12, state="readonly",
                                        values=["Term 1", "Term 2", "Term 3", "Term 4", "Final"])
        self.term_combo.grid(row=1, column=1, padx=4)

        tk.Label(form, text="Score (%)", bg="white", font=("Segoe UI", 9)).grid(row=0, column=2, sticky="w", padx=4)
        self.score_entry = ttk.Entry(form, width=10)
        self.score_entry.grid(row=1, column=2, padx=4)

        tk.Label(form, text="Test (optional)", bg="white", font=("Segoe UI", 9)).grid(row=0, column=3, sticky="w", padx=4)
        self.test_entry = ttk.Entry(form, width=10)
        self.test_entry.grid(row=1, column=3, padx=4)

        tk.Label(form, text="Exam (optional)", bg="white", font=("Segoe UI", 9)).grid(row=0, column=4, sticky="w", padx=4)
        self.exam_entry = ttk.Entry(form, width=10)
        self.exam_entry.grid(row=1, column=4, padx=4)

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Add Mark", bg=GOLD, fg="white", command=self.add_mark)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_mark)
        self.add_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)

        columns = ("id", "student", "subject", "term", "score", "test", "exam")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=14)
        for col, head in zip(columns, ["ID", "Student", "Subject", "Term", "Score", "Test", "Exam"]):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=200 if col == "subject" else 110)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        self.enrollment_lookup = {}
        self.refresh()

    def refresh(self):
        self.enrollment_lookup = {label: eid for eid, label in db.get_enrollment_choices()}
        self.enrollment_combo["values"] = list(self.enrollment_lookup.keys())

        for row in self.tree.get_children():
            self.tree.delete(row)
        for mark in db.get_all_marks():
            self.tree.insert("", "end", values=mark)

    def add_mark(self):
        enrollment_label = self.enrollment_combo.get()
        term = self.term_combo.get()
        score = self.score_entry.get().strip()
        if not (enrollment_label and term and score):
            messagebox.showwarning("Missing info", "Enrollment, term and score are all required.")
            return
        try:
            score_val = float(score)
            test_txt = self.test_entry.get().strip()
            exam_txt = self.exam_entry.get().strip()
            test_val = float(test_txt) if test_txt else None
            exam_val = float(exam_txt) if exam_txt else None
        except ValueError:
            messagebox.showwarning("Invalid mark", "Score, test and exam marks must be numbers.")
            return
        try:
            db.add_mark(self.enrollment_lookup[enrollment_label], term, score_val, test_val, exam_val)
        except Exception as ex:
            messagebox.showerror("Error", f"Could not add mark (score must be 0-100):\n{ex}")
            return
        self.refresh()
        for entry in (self.score_entry, self.test_entry, self.exam_entry):
            entry.delete(0, tk.END)

    def delete_mark(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a mark record in the table first.")
            return
        mark_id = self.tree.item(selected[0], "values")[0]
        if messagebox.askyesno("Confirm delete", "Delete the selected mark record?"):
            db.delete_mark(mark_id)
            self.refresh()

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["MarksFrame"])
        set_buttons_state([self.add_btn, self.delete_btn], editable)
