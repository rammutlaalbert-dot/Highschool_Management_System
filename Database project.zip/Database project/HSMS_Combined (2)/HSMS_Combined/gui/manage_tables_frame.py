import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header

GOLD = "#B8860B"
COLUMN_TYPES = ["INTEGER", "TEXT", "REAL", "DATE", "BOOLEAN"]


class ManageTablesFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        build_header(self, controller, "Manage Tables (Administrator)")

        body = tk.Frame(self, bg="white")
        body.pack(fill="both", expand=True, padx=20, pady=10)


        create_panel = tk.LabelFrame(body, text="Create a new table", bg="white")
        create_panel.pack(side="left", fill="both", expand=True, padx=(0, 10))

        name_row = tk.Frame(create_panel, bg="white")
        name_row.pack(fill="x", padx=10, pady=10)
        tk.Label(name_row, text="Table name:", bg="white").pack(side="left")
        self.table_name_entry = ttk.Entry(name_row, width=20)
        self.table_name_entry.pack(side="left", padx=6)

        self.column_model = ttk.Treeview(create_panel, columns=("name", "type", "pk"),
                                          show="headings", height=8)
        for col, head in zip(("name", "type", "pk"), ("Column Name", "Type", "Primary Key")):
            self.column_model.heading(col, text=head)
        self.column_model.pack(fill="both", expand=True, padx=10, pady=5)

        col_input_row = tk.Frame(create_panel, bg="white")
        col_input_row.pack(fill="x", padx=10, pady=5)
        self.col_name_entry = ttk.Entry(col_input_row, width=14)
        self.col_name_entry.pack(side="left", padx=2)
        self.col_type_combo = ttk.Combobox(col_input_row, width=10, state="readonly", values=COLUMN_TYPES)
        self.col_type_combo.set(COLUMN_TYPES[0])
        self.col_type_combo.pack(side="left", padx=2)
        self.pk_var = tk.BooleanVar()
        tk.Checkbutton(col_input_row, text="PK", variable=self.pk_var, bg="white").pack(side="left", padx=2)
        tk.Button(col_input_row, text="Add Column", command=self.add_column).pack(side="left", padx=4)

        tk.Button(create_panel, text="Create Table", bg=GOLD, fg="white",
                  command=self.create_table).pack(fill="x", padx=10, pady=10)


        drop_panel = tk.LabelFrame(body, text="Existing tables", bg="white")
        drop_panel.pack(side="left", fill="both", expand=True)

        self.table_list = tk.Listbox(drop_panel)
        self.table_list.pack(fill="both", expand=True, padx=10, pady=10)

        drop_btns = tk.Frame(drop_panel, bg="white")
        drop_btns.pack(fill="x", padx=10, pady=(0, 10))
        tk.Button(drop_btns, text="Refresh List", command=self.refresh_tables).pack(side="left", padx=2)
        tk.Button(drop_btns, text="Remove Selected Table", bg="#C62828", fg="white",
                  command=self.drop_table).pack(side="left", padx=2)

        self.refresh_tables()

    def add_column(self):
        name = self.col_name_entry.get().strip()
        col_type = self.col_type_combo.get()
        pk = "Yes" if self.pk_var.get() else "No"
        if not name:
            messagebox.showwarning("Missing info", "Enter a column name.")
            return
        self.column_model.insert("", "end", values=(name, col_type, pk))
        self.col_name_entry.delete(0, tk.END)
        self.pk_var.set(False)

    def create_table(self):
        table_name = self.table_name_entry.get().strip()
        rows = self.column_model.get_children()
        if not table_name or not rows:
            messagebox.showwarning("Missing info", "Provide a table name and at least one column.")
            return

        columns = []
        for row_id in rows:
            name, col_type, pk = self.column_model.item(row_id, "values")
            columns.append((name, col_type, pk == "Yes"))

        try:
            db.create_dynamic_table(table_name, columns)
        except Exception as ex:
            messagebox.showerror("Error", f"Could not create table:\n{ex}")
            return

        messagebox.showinfo("Success", f"Table '{table_name}' created.")
        self.table_name_entry.delete(0, tk.END)
        self.column_model.delete(*self.column_model.get_children())
        self.refresh_tables()

    def refresh_tables(self):
        self.table_list.delete(0, tk.END)
        for name in db.list_all_tables():
            self.table_list.insert(tk.END, name)

    def drop_table(self):
        selection = self.table_list.curselection()
        if not selection:
            messagebox.showwarning("No selection", "Select a table to remove.")
            return
        table_name = self.table_list.get(selection[0])

        core_tables = {"users", "students", "teachers", "classes", "subjects",
                        "teacher_subject", "enrollment", "marks", "attendance"}
        if table_name in core_tables:
            messagebox.showwarning("Not allowed",
                                    "This is one of the 9 core system tables and can't be removed here.")
            return

        if messagebox.askyesno("Confirm delete",
                                f"Permanently delete table '{table_name}' and all its data?"):
            try:
                db.drop_dynamic_table(table_name)
            except Exception as ex:
                messagebox.showerror("Error", f"Could not remove table:\n{ex}")
                return
            self.refresh_tables()

    def on_show(self):
        self.refresh_tables()
