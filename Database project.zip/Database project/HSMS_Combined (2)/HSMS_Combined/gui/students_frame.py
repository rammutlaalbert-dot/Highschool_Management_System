import tkinter as tk
from tkinter import ttk, messagebox
import data_access as db
from gui.widgets import build_header, can_edit, set_buttons_state, EDIT_ROLES

GOLD = "#B8860B"


class StudentsFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller
        self.selected_id = None
        self.class_lookup = {}

        build_header(self, controller, "Students")


        search_frame = tk.Frame(self, bg="white")
        search_frame.pack(fill="x", padx=20, pady=(10, 0))
        tk.Label(search_frame, text="Search by name:", bg="white").pack(side="left")
        self.search_entry = ttk.Entry(search_frame, width=25)
        self.search_entry.pack(side="left", padx=6)
        self.search_entry.bind("<KeyRelease>", lambda e: self.refresh())
        tk.Button(search_frame, text="Clear Search", command=self.clear_search).pack(side="left", padx=4)


        form = tk.Frame(self, bg="white")
        form.pack(fill="x", padx=20, pady=15)

        tk.Label(form, text="First Name", bg="white", font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", padx=4)
        self.first_entry = ttk.Entry(form, width=14)
        self.first_entry.grid(row=1, column=0, padx=4)

        tk.Label(form, text="Last Name", bg="white", font=("Segoe UI", 9)).grid(row=0, column=1, sticky="w", padx=4)
        self.last_entry = ttk.Entry(form, width=14)
        self.last_entry.grid(row=1, column=1, padx=4)

        tk.Label(form, text="DOB (YYYY-MM-DD)", bg="white", font=("Segoe UI", 9)).grid(row=0, column=2, sticky="w", padx=4)
        self.dob_entry = ttk.Entry(form, width=14)
        self.dob_entry.grid(row=1, column=2, padx=4)

        tk.Label(form, text="Gender", bg="white", font=("Segoe UI", 9)).grid(row=0, column=3, sticky="w", padx=4)
        self.gender_combo = ttk.Combobox(form, width=10, state="readonly", values=["Male", "Female", "Other"])
        self.gender_combo.grid(row=1, column=3, padx=4)

        tk.Label(form, text="Class", bg="white", font=("Segoe UI", 9)).grid(row=0, column=4, sticky="w", padx=4)
        self.class_combo = ttk.Combobox(form, width=14, state="readonly")
        self.class_combo.grid(row=1, column=4, padx=4)

        tk.Label(form, text="Parent Contact", bg="white", font=("Segoe UI", 9)).grid(row=0, column=5, sticky="w", padx=4)
        self.contact_entry = ttk.Entry(form, width=14)
        self.contact_entry.grid(row=1, column=5, padx=4)

        tk.Label(form, text="Address", bg="white", font=("Segoe UI", 9)).grid(row=0, column=6, sticky="w", padx=4)
        self.address_entry = ttk.Entry(form, width=16)
        self.address_entry.grid(row=1, column=6, padx=4)

        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        self.add_btn = tk.Button(btn_frame, text="Add Student", bg=GOLD, fg="white", command=self.add_student)
        self.update_btn = tk.Button(btn_frame, text="Update Selected", bg="#1565C0", fg="white",
                                     command=self.update_student)
        self.delete_btn = tk.Button(btn_frame, text="Delete Selected", bg="#C62828", fg="white",
                                     command=self.delete_student)
        self.clear_btn = tk.Button(btn_frame, text="Clear Form", command=self.clear_form)
        self.add_btn.pack(side="left", padx=4)
        self.update_btn.pack(side="left", padx=4)
        self.delete_btn.pack(side="left", padx=4)
        self.clear_btn.pack(side="left", padx=4)

        columns = ("id", "first", "last", "dob", "gender", "class", "contact", "address")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=12)
        headers = ["ID", "First Name", "Last Name", "DOB", "Gender", "Class", "Parent Contact", "Address"]
        for col, head in zip(columns, headers):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=95)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)
        self.tree.bind("<<TreeviewSelect>>", self.on_row_select)

        self.refresh()

    def refresh(self):
        self.class_lookup = {name: cid for cid, name in db.get_class_choices()}
        self.class_combo["values"] = list(self.class_lookup.keys())

        for row in self.tree.get_children():
            self.tree.delete(row)
        keyword = self.search_entry.get().strip()
        students = db.search_students(keyword) if keyword else db.get_all_students()
        for student in students:
            self.tree.insert("", "end", values=student)

    def clear_search(self):
        self.search_entry.delete(0, tk.END)
        self.refresh()

    def on_row_select(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        values = self.tree.item(selected[0], "values")
        self.selected_id = values[0]
        self.first_entry.delete(0, tk.END); self.first_entry.insert(0, values[1])
        self.last_entry.delete(0, tk.END); self.last_entry.insert(0, values[2])
        self.dob_entry.delete(0, tk.END); self.dob_entry.insert(0, values[3])
        self.gender_combo.set(values[4])
        self.class_combo.set(values[5] if values[5] != "(unassigned)" else "")
        self.contact_entry.delete(0, tk.END); self.contact_entry.insert(0, values[6])
        self.address_entry.delete(0, tk.END); self.address_entry.insert(0, values[7])

    def _collect_form(self):
        class_id = self.class_lookup.get(self.class_combo.get())
        return (self.first_entry.get().strip(), self.last_entry.get().strip(),
                self.dob_entry.get().strip(), self.gender_combo.get(),
                class_id, self.contact_entry.get().strip(), self.address_entry.get().strip())

    def add_student(self):
        values = self._collect_form()
        if not values[0] or not values[1]:
            messagebox.showwarning("Missing info", "First and last name are required.")
            return
        db.add_student(*values)
        self.refresh()
        self.clear_form()

    def update_student(self):
        if not self.selected_id:
            messagebox.showwarning("No selection", "Select a student in the table first.")
            return
        db.update_student(self.selected_id, *self._collect_form())
        self.refresh()
        self.clear_form()

    def delete_student(self):
        if not self.selected_id:
            messagebox.showwarning("No selection", "Select a student in the table first.")
            return
        if messagebox.askyesno("Confirm delete", "Delete the selected student?"):
            db.delete_student(self.selected_id)
            self.refresh()
            self.clear_form()

    def clear_form(self):
        self.selected_id = None
        for entry in [self.first_entry, self.last_entry, self.dob_entry, self.contact_entry, self.address_entry]:
            entry.delete(0, tk.END)
        self.gender_combo.set("")
        self.class_combo.set("")
        self.tree.selection_remove(self.tree.selection())

    def on_show(self):
        self.refresh()
        editable = can_edit(self.controller, EDIT_ROLES["StudentsFrame"])
        set_buttons_state([self.add_btn, self.update_btn, self.delete_btn], editable)
