"""Rebuild school.db by running the SQL script data/hsms_sqlite.sql.

    python load_sql.py                 # uses data/hsms_sqlite.sql
    python load_sql.py my_script.sql   # or any other SQL script

The old school.db is replaced.
"""
import os
import sqlite3
import sys

from backend import data_access as db

script = sys.argv[1] if len(sys.argv) > 1 else os.path.join(db.BASE_DIR, "data", "hsms_sqlite.sql")
with open(script, encoding="utf8") as f:
    sql = f.read()

if os.path.exists(db.DB_FILE):
    os.remove(db.DB_FILE)
conn = sqlite3.connect(db.DB_FILE)
conn.executescript(sql)
conn.close()

db.initialise_database()   # adds anything the script did not create; never touches existing rows
conn = db.get_connection()
problems = conn.execute("PRAGMA foreign_key_check").fetchall()
print("Loaded", script)
for t in db.list_all_tables():
    print(f"  {t:18s}{conn.execute(f'SELECT COUNT(*) FROM \"{t}\"').fetchone()[0]:>6}")
print("Foreign-key problems:", len(problems))
conn.close()
