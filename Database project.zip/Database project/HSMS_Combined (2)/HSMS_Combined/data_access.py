# Compatibility layer for the existing Tkinter application.
# Your App currently uses: import data_access as db
# This keeps that directory/import unchanged while the real backend lives in backend/data_access.py.
from backend.data_access import *
