@echo off
cd /d "%~dp0"
title High School Management System

rem Try the Windows "py" launcher first, then plain "python".
where py >nul 2>nul
if %errorlevel%==0 (
    py main.py
    goto :done
)
where python >nul 2>nul
if %errorlevel%==0 (
    python main.py
    goto :done
)

echo Python was not found. Install Python 3 from https://www.python.org/downloads/
echo and tick "Add python.exe to PATH" during setup.
pause
exit /b 1

:done
if errorlevel 1 (
    echo.
    echo The program closed with an error. See the message above.
    pause
)
