# High School Management System (combined)

Tkinter GUI (from `HSMS_Interface`) + Python/SQLite backend (from `HSMS_backend_new`),
pre-loaded with all the data from the MySQL dump `mydb.sql`.

## Run

Double-click **`run_hsms.bat`** (Windows), or run:

```
python main.py
```

`school.db` is already built and populated. Needs Python 3 with tkinter (bundled on Windows/macOS;
on Linux install `python3-tk`).

### Loading the data with SQL

The finished data is also available as plain SQL scripts (schema + INSERT statements for every table):

| File | Use it for |
|---|---|
| `data/hsms_sqlite.sql` | the app's own SQLite database: `python load_sql.py` rebuilds `school.db` from it |
| `data/hsms_mysql.sql` | MySQL / MariaDB: in Workbench use *File > Run SQL Script*; it creates and fills a database called `hsms` |
| `data/mydb.sql` | the original dump you supplied (different table layout) |

Other ways to rebuild `school.db` (both overwrite it):

```
python load_sql.py                      # from data/hsms_sqlite.sql
python -m backend.import_mysql_dump     # from the original dump data/mydb.sql
```

After changing data in the app, `python -m backend.export_sql` regenerates the two SQL scripts.

## Logins (from the dump's `users` table)

| Role | Username | Password |
|---|---|---|
| Administrator | admin | Admin@123 |
| Principal | principal | Principal@123 |
| Teacher | teacher1 | NewPass@999 |
| Teacher | teacher2 ... teacher15 | Teacher@124 ... Teacher@137 (teacherN = Teacher@(122+N)) |

The old demo logins (admin/admin123 etc.) no longer exist. Passwords are plain text, as in the
original project; hash them before any real use.

## What each role can do

| Screen | Administrator | Principal | Teacher |
|---|---|---|---|
| Users, Manage Tables | full | - | - |
| Teachers, Classes, Subjects, Teacher-Subject | full | full | - |
| Students, Enrollment, Marks, Attendance | full | full | full |
| Reports | view | view | view |

"Full" means the Add / Update / Delete buttons work. To change this, edit `EDIT_ROLES` in `gui/widgets.py`
(button permissions) and `TILES_BY_ROLE` in `gui/dashboard_frame.py` (which tiles each role sees).

## Layout

```
main.py                    entry point (unchanged interface app)
data_access.py             bridge so `import data_access as db` keeps working
run_backend.py             initialise / sanity-check the database
backend/data_access.py     the backend (all SQL lives here)
backend/import_mysql_dump.py   loads data/mydb.sql into school.db
backend/export_sql.py      writes school.db out as data/hsms_sqlite.sql and data/hsms_mysql.sql
load_sql.py                rebuilds school.db by running data/hsms_sqlite.sql
backend/data_access_reference.txt  original data_access from the interface, for comparison
data/mydb.sql              the original MySQL dump you supplied
data/hsms_sqlite.sql, hsms_mysql.sql   the final data as SQL scripts
gui/                       Tkinter screens
legacy/school_original_demo.db     the demo database that shipped inside HSMS_Interface.zip
er_diagram.png, BUILD_GUIDE.md     from the interface project (er_diagram predates the schema additions below)
school.db                  the combined, populated database
```

## What was loaded, and how it was mapped

| MySQL dump | Rows | Goes into | Notes |
|---|---|---|---|
| teacher | 16 | teachers | surname -> last_name, speciality -> specialty |
| class | 15 | classes | "A" + grade 8 becomes `8A` / `Grade 8`; `current_year` kept |
| student | 76 | students | unchanged |
| subjects | 35 | subjects | `grade` and lead `teacher_id` kept as new columns |
| teacher_subject | 82 | teacher_subject | 3 duplicate pairs merged -> 79 |
| users | 17 | users | role `Admin` -> `Administrator`; `teacher_id` link kept |
| enrollment | 75 | **class_enrollment** (new) | student-in-class per year + status |
| marks | 525 | enrollment (525) + marks (525) | see below |
| attendance | 225 | attendance | attendance_status -> status |

The two designs disagree about "enrollment" and "marks", so:

* The dump's `enrollment` is student -> **class**; the app's `enrollment` is student -> **subject**.
  The dump's version is kept in a new `class_enrollment` table (browse it in Manage Tables); the app's
  subject enrollments are created from the (student, subject) pairs that have marks.
* The dump's marks have test / exam / final. Each becomes one `marks` row with `term = 'Final'`,
  `score` = final mark, plus new `test_mark` and `exam_mark` columns. Reports use `score`.

Because subject names repeat across grades, screens and reports show them as `English (Grade 8)`.

## Backend / GUI changes

* Backend schema extended (`classes.current_year`, `subjects.grade/teacher_id`, `users.teacher_id`,
  `marks.test_mark/exam_mark`, `class_enrollment`); older databases are upgraded automatically.
* Reports screen now has all 8 backend reports (the interface only had 5, and its
  Academic Performance headers no longer matched the new query).
* Subjects screen shows/sets grade and lead teacher; Marks screen shows/sets test and exam marks
  and accepts the `Final` term.

## Data issues found in the source (kept as-is)

* Student 226 (Thabo Mokoena) is in class 8B in `student` but 8A in the class enrollment record.
* Student 301 (Anele Nkosi) has no class enrollment, marks or subject enrollments.
* `teacher_subject`, `subjects.teacher_id` and each teacher's `speciality` text don't fully agree.
* The dump has no homeroom teachers. Each class is given one automatically (a different teacher per class,
  who teaches that grade, preferring those with more subjects in it). This is a starting point, not source
  data - change it on the Classes screen (select a row, pick a teacher, **Update Selected**).
