
import tkinter as tk
from tkinter import messagebox
import traceback
import data_access as db

from gui.login_frame import LoginFrame
from gui.dashboard_frame import DashboardFrame
from gui.users_frame import UsersFrame
from gui.students_frame import StudentsFrame
from gui.teachers_frame import TeachersFrame
from gui.classes_frame import ClassesFrame
from gui.subjects_frame import SubjectsFrame
from gui.teacher_subject_frame import TeacherSubjectFrame
from gui.enrollment_frame import EnrollmentFrame
from gui.marks_frame import MarksFrame
from gui.attendance_frame import AttendanceFrame
from gui.reports_frame import ReportsFrame
from gui.manage_tables_frame import ManageTablesFrame


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("High School Management System")
        self.geometry("1150x700")
        self.minsize(950, 600)

        self.current_user = None

        container = tk.Frame(self)
        container.pack(fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        frame_classes = [
            LoginFrame, DashboardFrame, UsersFrame, StudentsFrame, TeachersFrame,
            ClassesFrame, SubjectsFrame, TeacherSubjectFrame, EnrollmentFrame,
            MarksFrame, AttendanceFrame, ReportsFrame, ManageTablesFrame,
        ]
        for FrameClass in frame_classes:
            frame = FrameClass(container, self)
            self.frames[FrameClass.__name__] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("LoginFrame")

    def report_callback_exception(self, exc_type, exc_value, exc_tb):
        # Without this, a failing button only prints to the console and looks like it does nothing.
        traceback.print_exception(exc_type, exc_value, exc_tb)
        messagebox.showerror("Something went wrong", f"{exc_type.__name__}: {exc_value}")

    def show_frame(self, name):
        frame = self.frames[name]
        if hasattr(frame, "on_show"):
            frame.on_show()
        frame.tkraise()


if __name__ == "__main__":
    db.initialise_database()
    app = App()
    app.mainloop()
